#include<stdio.h>
int main()
{
int a, b=10, c=5;
a=b+c;
printf("%d", a);
}